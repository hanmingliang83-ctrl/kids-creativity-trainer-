"""创造力评估工具 - #51"""

def calc_creativity(fluency, flexibility, originality, elaboration, age):
    weights = {"fluency": 0.20, "flexibility": 0.25, "originality": 0.35, "elaboration": 0.20}
    total = fluency*0.20 + flexibility*0.25 + originality*0.35 + elaboration*0.20
    
    if age >= 12: weights["elaboration"] = 0.25
    
    if total >= 85: level = "卓越"
    elif total >= 70: level = "优秀"
    elif total >= 50: level = "良好"
    elif total >= 30: level = "发展中"
    else: level = "待激发"
    
    return {"total": round(total, 1), "level": level, 
            "dimensions": {"流畅性": fluency, "灵活性": flexibility, 
                          "独创性": originality, "精致性": elaboration}}
