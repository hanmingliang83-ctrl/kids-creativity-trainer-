"""#51 创造力培养师 - 对话智能体主程序"""

from typing import Optional
from pydantic import BaseModel

class ChildInfo(BaseModel):
    child_id: str
    name: str
    age: int
    creativity_level: float = 50.0
    interests: list = []

class ChatRequest(BaseModel):
    child_id: str
    message: str

class ChatResponse(BaseModel):
    reply: str
    suggestion: Optional[str] = ""

class CreativityAssessment(BaseModel):
    fluency: float
    flexibility: float
    originality: float
    elaboration: float
    total: float

# FastAPI routes:
# POST /api/chat
# POST /api/assessment
# POST /api/challenge/create
# GET /api/progress/{child_id}
